from sklearn.gaussian_process.kernels import Matern
from sklearn.gaussian_process import GaussianProcessRegressor

import numpy as np
from scipy.optimize import minimize
from acqusition_func import Acqusition_func


class GaussianProcess:
    def __init__(self, kind):
        """
        A function to perform the Gaussian Process with a Gaussian Process Regressor
        ----------
        :param kind:
        The kind of Acqusiton function used
        """
        self.acq_func = Acqusition_func()
        self.acq_kind = kind
        self.kappa = 2.5
        self.max_acq = None
        self.hyp = []

        self._gp = GaussianProcessRegressor(
            kernel=Matern(nu=2.5), alpha=1e-6, normalize_y=True, n_restarts_optimizer=25
        )

    #GPR takes the tested Hyperparameter with results and save it in a generalized way
    def fit(self, hp_array, result):
        self._gp.fit(hp_array, result)

    #
    def find_new_hp(self, hp, bounds, lin, y_max):

        self.ys = self.acq_func.get_acq(
            points=hp, gp=self._gp, result_max=y_max, kindAcq=self.acq_kind
        )
        self.max_acq = self.ys.max()

        for x in lin:
            res = minimize(
                lambda x: -self.acq_func.get_acq(
                    x.reshape(1, -1),
                    gp=self._gp,
                    kappa=self.kappa,
                    result_max=y_max,
                    kindAcq=self.acq_kind,
                ),
                x.reshape(1, -1),
                bounds=bounds,
                method="L-BFGS-B",
            )
            if not res.success:
                continue

            # Store it if better than previous minimum(maximum).
            if self.max_acq is None or -res.fun[0] >= self.max_acq:
                hp_max = res.x
                # self.max_acq = -res.fun[0]
                self.hyp = hp_max
        return self.hyp


    def set_acq_func(self, kind):
        self.acq_func = kind

    def set_gp(self, gp=None):
        # Internal GP regressor
        if gp is None:
            _gp = GaussianProcessRegressor(
                kernel=Matern(nu=2.5),
                alpha=1e-6,
                normalize_y=True,
                n_restarts_optimizer=25,
            )
        else:
            _gp = gp
        return _gp
