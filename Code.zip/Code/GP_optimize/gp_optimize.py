from gaussian_process import GaussianProcess
import numpy as np
import math as math

from util import (
    get_sorted_keylist,
    dict_to_array,
    get_linspace,
    random_try,
    array_to_dict,
    split_random
    
)


class GPOptimize:
    def __init__(self, spaces, kind,random_tries,  func= None, linpoints=250):
        """
        A function to initiate all the variables that are needed for the optimization.
        ----------
        :param func:
        The actual Function where we try to optimize the Parameter.
        :param spaces:
        It is a dictionary with the name of the Hyperparameter as Key and the Value is a Tuple
        of the min and max possible value for this Hyperparameter.
        :param kind:
        That is the kind of Acqusition function is be used.
        At the moment is ei, poi and ucb available.
        :param linpoints:
        These are the amount of points in each space that will be tested for optimization
        """

        self.gaussian_process = GaussianProcess(kind)

        self.func = func

        self.tried = 0
        self.random_tries = random_tries
        self.spaces = spaces
        self.keys_spaces = get_sorted_keylist(spaces)
        self.spaces_array = dict_to_array(spaces)
        self.lin_space = get_linspace(spaces,linpoints)
        self.lin_space = dict_to_array(self.lin_space).T

        self.result_max = -math.inf

        self.results = []
        self.hp = []



    def work_for_steps(self, steps):
        for x in range(steps):
            self.do_one_step()

    # this is one cycle of gaussian process
    def do_one_step(self):
        new_hp = self.get_new_hp()
        print(new_hp) # to see which hp is choosen
        result = self.try_hp(new_hp)
        self.update_new_hp(result)

    def fit(self):
        self.gaussian_process.fit(self.hp, self.results)



    def get_new_hp(self):
        if self.tried < self.random_tries:
            #new_hp_dict = random_try(self.spaces)
            self.new_hp_dict = split_random(self.spaces, self.tried, self.random_tries)
            return self.new_hp_dict
        
        self.fit()
        self.new_hp = self.gaussian_process.find_new_hp(
            self.hp, self.spaces_array, self.lin_space, self.result_max)
        new_hp_dict = array_to_dict(self.keys_spaces, self.new_hp)
        # when gaussian process regressor don't find a new hp then choose a random
        if not any(new_hp_dict) or self.new_hp_dict ==  new_hp_dict:
            print("No maximum found. Tried random.")
            new_hp_dict = random_try(self.spaces)
        self.new_hp_dict = new_hp_dict
        return new_hp_dict
        
    #when a function is given it can be testet here
    def try_hp(self, new_hp):
        result = self.func(**new_hp)
        return result

    # stores the new Hyperparamter in self.hp und the new result in self.result
    def update_new_hp(self, result):
        if result > self.result_max:
            self.result_max = result
            self.max_hp = self.new_hp_dict
        new_hp_array = dict_to_array(self.new_hp_dict)
        if self.tried < 1:
            self.hp = new_hp_array
            self.results = [result]
        else: 
            self.hp = np.vstack((self.hp, new_hp_array))
             
            self.results = np.append(self.results, result)
        self.tried += 1



    # def for setting parameter
    def set_kind_acq(self, kind):
        self.gaussian_process.set_acq_func(kind)

    def set_randomtries(self, tries):
        self.random_tries = tries
