import warnings

import numpy as np
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor


class Acqusition_func:
    def get_acq(self, points: np.array, gp: GaussianProcessRegressor, result_max: float, kindAcq: str, kappa: float = 2.5):
        """
        A function
        ----------
        :param points:
        These are the x values. In multidimensional problems it is a array of
        a whole set of values for each hyperparameter to calculate the acqusition function.
        :param gp:
        A gaussian process regressor from sklearn
        :param result_max:
        this is the best result so far from the real function
        :param kindAcq:
        The kind of Acqusiton function used
        :param kappa:
        A variable to use in the upper bound confident function to tame the exploitative part.
        """
        if kindAcq == "ubc":
            return self._ubc(points, gp, kappa)
        if kindAcq == "poi":
            return self._poi(points, gp, result_max, xi=0.0)

        return self._ei(points, gp, result_max, xi=0.0)

    #most explorativ function
    def _ei(self, hp, gp, result_max, xi):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mean, std = gp.predict(hp, return_std=True)
        z = (mean - result_max - xi) / std
        return (mean - result_max - xi) * norm.cdf(z) + std * norm.pdf(z)

    def _ubc(self, hp, gp, kappa=2.576):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mean, std = gp.predict(hp, return_std=True)

        return mean + kappa * std

    # most exploitative function
    def _poi(self, hp, gp, result_max, xi):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mean, std = gp.predict(hp, return_std=True)

        z = (mean - result_max - xi) / std

        return norm.cdf(z)
