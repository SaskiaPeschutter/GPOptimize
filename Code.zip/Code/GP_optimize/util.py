import numpy as np
import random as rn

#only a handful of little helper functions

#takes a dict with spaces
# returns   for each key in the dic an dict with array with the space and amount of number by the amount of i
def get_linspace(space, i):
    return {key: np.linspace(space[key][0], space[key][1], i) for key in space}

# Get the name of the parameters sorted
# Create an array with values of the dict
def dict_to_array(d):

    return np.array(
        [item[1] for item in sorted(d.items(), key=lambda x: x[0])], dtype=np.float
    )

# returns the dict sorted
def get_sorted_keylist(d):
    return [key for key in sorted(d.keys(), key=lambda x: x[0])]

# zips keys and an array back to a dict
def array_to_dict(keys, values):
    return dict(zip(keys, values))

# returns random number in the space
def random_try(space):
    next_n = {}
    for i in space:
        next_n[i] = rn.uniform(space[i][0], space[i][1])

    return next_n

# splits the space into the amount of tries
#returns a random number out of the "tried" section
def split_random(space,tried, tries):
    next_n = {}
    for i in space:
        n = np.linspace(space[i][0],space[i][1],tries +1)
        next_n[i] = rn.uniform(n[tried], n[tried+1]) 
                             
    return next_n

#returns a random value which is not so near to the previous one
def random_try_spaced(space, old_hp):
    next_n = {}
    for i in space:
        s = 0.1
        while True:
            next_n[i] = rn.uniform(space[i][0], space[i][1])
            if next_n[i] > old_hp[i] + s or next_n[i] < old_hp[i] - s :
                break

    return next_n