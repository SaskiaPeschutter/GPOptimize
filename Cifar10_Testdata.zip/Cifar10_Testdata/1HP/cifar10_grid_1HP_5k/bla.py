import glob
import re

rex = re.compile('Trainer_\d+_(\w+=[\d\.]+)(?:,(\w+=[\d\.]+))*_\d{4}')

for f in glob.glob('./*'):
    print(f)
    pairs = rex.search(f).groups()
    print(pairs)
    params = {p.split('=')[0]: p.split('=')[1] for p in pairs}
    print(params)